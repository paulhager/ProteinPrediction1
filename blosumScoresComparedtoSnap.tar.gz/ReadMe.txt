Usage:

python3 main.py --fastaFolder pathtofastafolder --snapFolder pathtosnapfolder --bindingResidues pathtobindingresiduesfile --trainedModel pathtomodel/trainedModel.pickle

note: loaded data will be automatically written to pickle files. To use (after first run) add --pickleTrain train2.pickle --pickleLabel labels.pickle


